import { auxMeth } from "./auxmeth.js";

export const SBOX = {};

SBOX.templates =[];
SBOX.sheethtml;
SBOX.showshield=false;
SBOX.diff={};

